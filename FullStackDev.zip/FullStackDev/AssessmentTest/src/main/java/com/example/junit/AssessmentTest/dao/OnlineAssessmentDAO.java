package com.example.junit.AssessmentTest.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.junit.AssessmentTest.Entity.QuesAnsSet;
@Repository
public interface OnlineAssessmentDAO extends JpaRepository<QuesAnsSet, Integer> {

	public List<QuesAnsSet> findByAssessmentType(String assessmentType);

}
