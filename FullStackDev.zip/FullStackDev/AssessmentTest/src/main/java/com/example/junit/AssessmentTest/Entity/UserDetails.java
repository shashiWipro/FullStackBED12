package com.example.junit.AssessmentTest.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.hateoas.ResourceSupport;

@Entity
@Table(name="UserDetails")
public class UserDetails  extends ResourceSupport {
    
	@Id
	private Integer uid;
	private String firstName;
	private String lastName;
	private String email;
	private String password;
	private String userType;
	private String testdate;
	private String assesment;
	private String totalMarks;
	private String markObtained;
	private String result;
	
	
	
	public UserDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public UserDetails(Integer uid, String firstName, String lastName, String email,String password, String userType) {
		super();
		this.uid = uid;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password=password;
		this.userType = userType;
	}



	public UserDetails(Integer uid, String firstName, String lastName, String email, String userType, String testdate,
			String assesment, String totalMarks, String markObtained, String result) {
		super();
		this.uid = uid;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.userType = userType;
		this.testdate = testdate;
		this.assesment = assesment;
		this.totalMarks = totalMarks;
		this.markObtained = markObtained;
		this.result = result;
	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getTestdate() {
		return testdate;
	}
	public void setTestdate(String testdate) {
		this.testdate = testdate;
	}
	public String getAssesment() {
		return assesment;
	}
	public void setAssesment(String assesment) {
		this.assesment = assesment;
	}
	public String getTotalMarks() {
		return totalMarks;
	}
	public void setTotalMarks(String totalMarks) {
		this.totalMarks = totalMarks;
	}
	public String getMarkObtained() {
		return markObtained;
	}
	public void setMarkObtained(String markObtained) {
		this.markObtained = markObtained;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	
	
	
}
