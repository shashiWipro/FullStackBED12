package com.example.junit.AssessmentTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssessmentTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
