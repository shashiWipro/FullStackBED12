import { Component, OnInit } from '@angular/core';
import { Scorelist } from './scorelist';
import { StudentService } from '../student.service';
import { FormGroup, FormControl } from '@angular/forms';


@Component({
  selector: 'app-creditscore',
  templateUrl: './creditscore.component.html',
  styleUrls: ['./creditscore.component.css']
})
export class CreditscoreComponent implements OnInit {
     cardscore:Scorelist;
     pancardNo:string;
     creditCard:FormGroup;
  constructor(private _service:StudentService) { }

  ngOnInit() {
    
      this.creditCard=new FormGroup({
      pan:new FormControl('')
     
          })


    this._service.getScoreByPAN(this.pancardNo).subscribe(
      (score)=>{
        console.log(score[0].pancard);
        console.log(score[0].creditscore);
        this.cardscore=score[0];
        this.checkCreditScore(score[0].creditscore);
               }
           );

  }


  
  submitPAN(){
    
    if(this.creditCard.valid){
        console.log(this.creditCard.value.pan);
        this.pancardNo= this.creditCard.value.pan
        this.ngOnInit()
        console.log(this.pancardNo)
        console.log('the form is valid')
      }
        else {
          console.log('not a valid form')
      }
  }
 

checkCreditScore(score:number)
{
  if((score<10) && (score>9) )
  {
    //window.location.href='./sucess.html';
  console.log("Excelent");
  }
  if((score>6) && (score<9) )
  {
    //window.location.href='./sucess.html';
  console.log("Good Credit score");
  }
  if((score<6))
  {
   // window.location.href='./sucess.html';
  console.log("Poor Credit Score");
  }
}
}
