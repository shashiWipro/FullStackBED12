package com.bank.app.bankApplication.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bank.app.bankApplication.entity.CreditCardDetails;
import com.bank.app.bankApplication.service.CreditCardValidatorService;

@RestController
public class CreditCardValidatorController {


@Autowired
private CreditCardValidatorService service;

@PostMapping("/savedata/{scoreDetails}")
public String saveCreditDetails(@RequestBody CreditCardDetails scoreDetails)
{
	return service.saveCreditScoreDetails(scoreDetails);
}



@GetMapping(value ="/getscore/{panCardNo}")
@CrossOrigin(origins = "http://localhost:4200")
public  String getCreditScore(@PathVariable("panCardNo") String panCardNo)
{       if(panCardNo.isEmpty() || null==panCardNo)
      {
	return "Pan Card Field Can not be Empty";
	 
      }
		
else
    {
	return service.getCreditScore(panCardNo);
   }
	
}

}




