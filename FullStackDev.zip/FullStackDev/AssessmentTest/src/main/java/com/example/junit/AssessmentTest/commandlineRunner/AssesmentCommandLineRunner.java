package com.example.junit.AssessmentTest.commandlineRunner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.junit.AssessmentTest.Entity.QuesAnsSet;
import com.example.junit.AssessmentTest.Entity.UserDetails;
import com.example.junit.AssessmentTest.dao.OnlineAssessmentDAO;
import com.example.junit.AssessmentTest.dao.UserDetailsDAO;

@Component
public class AssesmentCommandLineRunner implements CommandLineRunner {

   
	@Autowired
	private OnlineAssessmentDAO creditScoreDAO;
	
	@Autowired 
	private UserDetailsDAO userDao;
	
	
	@Override
	public void run(String... args) throws Exception {
		addQuestionAnswer();
		addUsers();
		UserDetails userDetails = userDao.findByEmailAndPassword("shashi@gmail.com","12345");
		System.out.println(userDetails.getFirstName());
		
		/*
		 * List<UserDetails> userList=userDao.findByUserType("Candidate");
		 * for(UserDetails ud:userList) {
		 * System.out.println(ud.getFirstName()+"\t"+ud.getLastName()+"\t"+ud.getEmail()
		 * +"\t"+ud.getUserType()); }
		 */
	}

	 
  public void addQuestionAnswer()
  {
	  //List<QuesAnsSet> listOfQA=new ArrayList<QuesAnsSet>();
	  
	  QuesAnsSet qa1=new QuesAnsSet(1,"What is the full form of ORM?","Delhi", "Patna", "Kolkata",  "Object Relational Mapping", "Object Relational Mapping","Hibernate");
	  QuesAnsSet qa2=new QuesAnsSet(2,"What is spring?","27", "28", "29","J2EE App Development Framework", "J2EE App Development Framework","Spring");
	  QuesAnsSet qa3=new QuesAnsSet(3,"What is the full form of IOC?","Lion", "Tiger", "leopard", "Inversion Of Control", "Inversion Of Control","Spring");
	  QuesAnsSet qa4=new QuesAnsSet(4,"In Hibernate, based on directionality, what could be the mappings?","Parrot", "avc", "bcbcb","uni-directional & bi-directional", "uni-directional & bi-directional","Hibernate");
	  QuesAnsSet qa5=new QuesAnsSet(10,"In an Hibernate application, which file would have datasource details?","jan gan man", "bande matram", "om jai jag", "configuration file", "configuration file","Hibernate");
	  QuesAnsSet qa6=new QuesAnsSet(5,"What is the full form of HQL?","jan gan man", "bande matram", "om jai jag", "Hibernate Query Language", "Hibernate Query Language","Hibernate");
	  QuesAnsSet qa7=new QuesAnsSet(6,"In an Hibernate application, concurrency can be controlled by setting?","jan gan man", "bande matram", "om jai jag", "isolation levels", "isolation levels","Hibernate");
	  QuesAnsSet qa8=new QuesAnsSet(7,"What is the full form of AOP?","27", "28", "29", "Aspect Oriented Programming", "Aspect Oriented Programming","Spring");
	  QuesAnsSet qa9=new QuesAnsSet(8,"Which of the below is a spring container?","27", "28", "29", "Application Context", "Application Context","Spring");
	  QuesAnsSet qa10=new QuesAnsSet(9,"Which is Spring's front Controller Implementation?","27", "28", "29","Dispatcher Servlet", "Dispatcher Servlet","Spring");
	  creditScoreDAO.save(qa1);creditScoreDAO.save(qa2);creditScoreDAO.save(qa3);
	  creditScoreDAO.save(qa4);creditScoreDAO.save(qa5);
	  creditScoreDAO.save(qa6);creditScoreDAO.save(qa7);creditScoreDAO.save(qa8);
	  creditScoreDAO.save(qa9);creditScoreDAO.save(qa10);
	  
  }
  
  
  
  public void addUsers()
     {
	  UserDetails u1=new UserDetails(101,"shashi ", "bhushan", "shashi@gmail.com","12345", "Admin");
	  UserDetails u2=new UserDetails(102,"bhushan ", "jha", "bhushan@gmail.com","12345", "Candidate");
	  UserDetails u3=new UserDetails(103,"prasad ", "mishra", "prasad@gmail.com","12345", "Candidate");
	  UserDetails u4=new UserDetails(104,"yadav ", "ram", "yadav@gmail.com","12345" ,"Candidate");
	  userDao.save(u1); userDao.save(u2); userDao.save(u3); userDao.save(u4);
	  }
  
  
 
  }
  


	

