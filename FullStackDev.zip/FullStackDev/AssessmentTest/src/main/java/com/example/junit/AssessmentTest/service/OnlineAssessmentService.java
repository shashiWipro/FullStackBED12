package com.example.junit.AssessmentTest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.junit.AssessmentTest.Entity.QuesAnsSet;
import com.example.junit.AssessmentTest.dao.OnlineAssessmentDAO;

@Service
public class OnlineAssessmentService {
    @Autowired
	private OnlineAssessmentDAO creditScoreDao;
    
    public List<QuesAnsSet> getQAList()
    {
      List<QuesAnsSet> qaSet=	creditScoreDao.findAll();
      return qaSet;
    }
    
    public List<QuesAnsSet> getQAListByType(String assessmentType)
    {
      List<QuesAnsSet> qaSet=	creditScoreDao.findByAssessmentType(assessmentType);
      return qaSet;
    }
    
	/*
	 * public String correctCount(QuesAnsSet qaSet,String myChoice) {
	 * if(qaSet.getAnswer().equals(myChoice)) { return "correct"; } else { return
	 * "notCorrect"; } }
	 */
}
