package com.example.junit.AssessmentTest.Entity;

import org.springframework.hateoas.ResourceSupport;

public class LoginStatus extends ResourceSupport
{
private String userType;
private String message;
public LoginStatus() {
	super();
	// TODO Auto-generated constructor stub
}

public LoginStatus(String userType,String message) {
	super();
	this.userType = userType;
	this.message=message;
}

public String getUserType() {
	return userType;
}

public void setUserType(String userType) {
	this.userType = userType;
}

public String getMessage() {
	return message;
}

public void setMessage(String message) {
	this.message = message;
}

}
