package com.example.junit.AssessmentTest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.junit.AssessmentTest.Entity.UserDetails;
import com.example.junit.AssessmentTest.dao.UserDetailsDAO;

@Service
public class UserService {
	
@Autowired	
private UserDetailsDAO userDAO;

public List<UserDetails> getAllUsers()
{
	return userDAO.findAll();
}


public UserDetails getAllUsersById(Integer uid)
{
	return userDAO.findById(uid).get();
}


public List<UserDetails> getAllUsersByUserType(String userType)
{
	return userDAO.findByUserType(userType);
}

public UserDetails loginUser(String email,String password)
    {
	UserDetails findByEmailAndPassword = userDAO.findByEmailAndPassword(email, password);
	return findByEmailAndPassword;
	
    }

public  UserDetails findByEmail(String email)
{
	UserDetails savedDetails = userDAO.findByEmail(email);
	return savedDetails;
}


public  UserDetails UpdateUser(UserDetails userDetails)
{
	UserDetails savedDetails = userDAO.save(userDetails);
	return savedDetails;
}
	
}
