package com.example.junit.AssessmentTest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.junit.AssessmentTest.Entity.LoginStatus;
import com.example.junit.AssessmentTest.Entity.QuesAnsSet;
import com.example.junit.AssessmentTest.Entity.UserDetails;
import com.example.junit.AssessmentTest.service.OnlineAssessmentService;
import com.example.junit.AssessmentTest.service.UserService;

@RestController
public class OnlineAssessmentController {


@Autowired
private OnlineAssessmentService service;

@Autowired 
private UserService userService;


private String currentLogedInUser;
private UserDetails userDetails=new UserDetails();
UserDetails findByEmail;
String result;
Integer marks ;
String testdate;
String assessment;


@GetMapping("/qalist")
public List<QuesAnsSet> getQAList()
{
   return service.getQAList();	
}

@GetMapping("/qalist/{assessmentType}")
public List<QuesAnsSet> getQAListByType(@PathVariable String assessmentType)
{
   return service.getQAListByType(assessmentType);
}


@GetMapping("/users")
public List<UserDetails> findAllUsers()
{
	List<UserDetails> userList=userService.getAllUsers();	
	return userList;
	
	
}





@GetMapping("/usersbyId/{uid}")
public UserDetails findAllUsersByID(@PathVariable Integer uid)
{
	
	UserDetails userList=userService.getAllUsersById(uid);
	
    Link selfLink = ControllerLinkBuilder.linkTo(OnlineAssessmentController.class)
                                      .slash("qalist")
                                      .withRel("Take Test");
    userList.add(selfLink);
	return userList;
	
	
}

@GetMapping("/users/{userType}")
public List<UserDetails> findAllUsersByType(@PathVariable String userType)
{

	return userService.getAllUsersByUserType(userType);
}

@GetMapping("/users/{email}/{password}")
public LoginStatus loginUser(@PathVariable String email,@PathVariable String password)
{
	currentLogedInUser=email;
	LoginStatus loginStatus=new LoginStatus("Unknown UserType", "Can not login");

    Link selfLink = ControllerLinkBuilder.linkTo(OnlineAssessmentController.class)
                                      .slash("qalist")
                                      .slash("Hibernate")
                                      .withRel("Take Hibernate Test");

    Link selfLinkSpring = ControllerLinkBuilder.linkTo(OnlineAssessmentController.class)
            .slash("qalist")
            .slash("Spring")
            .withRel("Take Spring Test");
	
	UserDetails loginUser = userService.loginUser(email, password);
	if (null != loginUser && loginUser.getUserType()=="Candidate") {
		
		loginStatus=new LoginStatus(loginUser.getUserType(), "login Succefully");
		loginStatus.add(selfLink);
		loginStatus.add(selfLinkSpring);
		    return loginStatus;
	}
	if (null != loginUser && loginUser.getUserType()=="Admin") {
            loginStatus=new LoginStatus(loginUser.getUserType(), "login Succefully");
            //loginStatus.add(selfLink);  Only Candidates Can Take the Test
		    return loginStatus;
         }
	return loginStatus;
}

	/*
	 * @GetMapping("/checkcorrect/{qaSet}/{choice}") public String
	 * checkCorrectChoice(@RequestBody QuesAnsSet qaSet,@PathVariable String choice)
	 * { return service.correctCount(qaSet, choice); }
	 * 
	 */

@GetMapping("/qualcheck/{assesmentType}")
public String checkQualification(@PathVariable String assesmentType)
{
	assessment=assesmentType;
	int count=0;
	List<QuesAnsSet> qaList = service.getQAListByType(assesmentType );  
	for(QuesAnsSet qa:qaList)
	{
		if(qa.getAnswer().equals(qa.getOption1()))
		    {
			count++;
		    }
	}
	marks=count*10;
	if(marks > 30)
	{  
    result="Passed";
	return "Congratulations !! you have passed";
	
	}
	
	else
	{
	
	result="Failed";
	return "Better Luck Next time";	
	}
}


@GetMapping("/checkQualified/{questAnsSet}")
public String countCorrect(@RequestBody List<QuesAnsSet> questAnsSet)
	{
	  System.out.println(questAnsSet);
	
		  int correctCount=0;
		  int marks=0;
		  for(QuesAnsSet qa:questAnsSet) 
		  { 
			  if(!qa.getChoiceAns().isEmpty() && qa.getChoiceAns().equals(qa.getAnswer())) 
			  {
		       correctCount++;
		     }
	    }
		  marks=correctCount *5;
		  System.out.println(correctCount);
		  
		  if(marks > 15) {
			  return "Candidate Qualified the Test";
		  
		  }
		  
		  else { 
			  return "Not qualified the Test"; 
			  }
		  
		  
		 }


//Once we have taken the test //user currentLogedInUser
@GetMapping("/user/{email}")
public UserDetails findByEmail(@PathVariable String email)
{
	 findByEmail = userService.findByEmail(email);
	
	 return findByEmail;
}

@PostMapping("/users/{userDetails}")
public void updateUser(@RequestBody UserDetails userDetails)
    {
	UserDetails updateUser = userService.UpdateUser(userDetails);
    }

//Once we find ByEmail update the user
public String UpdateuserDetailsPostTest(String result,String marks,String testdate,String assessment)
   {
	findByEmail.setMarkObtained(marks);
	findByEmail.setResult(result);
	findByEmail.setTestdate(testdate);
	findByEmail.setAssesment(assessment);
	UserDetails updateUser = userService.UpdateUser(findByEmail);
	if (null !=updateUser) {
		return "updated the user succesfully";
	}
	return "Can not update";
   }
}




