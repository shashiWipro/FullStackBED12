package com.bank.app.bankApplication.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bank.app.bankApplication.entity.CreditCardDetails;
@Repository
public interface CreditScoreDAO extends JpaRepository<CreditCardDetails, Integer> {
public CreditCardDetails findByPancard(String panCardNo);

}
